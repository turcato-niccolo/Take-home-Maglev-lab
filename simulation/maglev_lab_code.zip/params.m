%params
m = 0.077; % 77g
b_s = 1;
z_eq = 0.05;
g = 9.81;
b_m = m*g*z_eq;
d = 0.0001;
i_max = 0.02;